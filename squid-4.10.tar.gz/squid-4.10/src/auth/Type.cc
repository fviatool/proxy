/*
 * Auto-Generated File. Changes will be destroyed.
 */
#include "squid.h"
#include "auth/Type.h"
namespace Auth
{

const char * Type_str[] = {
	"AUTH_UNKNOWN",
	"AUTH_BASIC",
	"AUTH_NTLM",
	"AUTH_DIGEST",
	"AUTH_NEGOTIATE",
	"AUTH_BROKEN"
};
}; // namespace Auth
